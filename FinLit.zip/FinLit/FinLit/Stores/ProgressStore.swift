import Foundation
import Combine

final class ProgressStore: ObservableObject {
    @Published private(set) var completedLessonIDs: Set<UUID> = []
    @Published private(set) var quizAttempts: [QuizAttempt] = []

    private let lessonsKey = "finlit.completedLessonIDs"
    private let quizKey = "finlit.quizAttempts"
    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        load()
    }

    // MARK: - Lessons

    func markLessonComplete(_ lesson: Lesson) {
        completedLessonIDs.insert(lesson.id)
        persistLessons()
    }

    func isLessonComplete(_ lesson: Lesson) -> Bool {
        completedLessonIDs.contains(lesson.id)
    }

    var totalLessons: Int { LessonData.all.count }

    var completedLessonCount: Int {
        LessonData.all.filter { completedLessonIDs.contains($0.id) }.count
    }

    var overallLessonProgress: Double {
        guard totalLessons > 0 else { return 0 }
        return Double(completedLessonCount) / Double(totalLessons)
    }

    func progress(for category: LessonCategory) -> Double {
        let lessons = LessonData.lessons(for: category)
        guard !lessons.isEmpty else { return 0 }
        let done = lessons.filter { completedLessonIDs.contains($0.id) }.count
        return Double(done) / Double(lessons.count)
    }

    // MARK: - Quizzes

    func recordQuizAttempt(category: LessonCategory, score: Int, total: Int) {
        let attempt = QuizAttempt(category: category, score: score, total: total, date: Date())
        quizAttempts.append(attempt)
        persistQuizAttempts()
    }

    func bestAttempt(for category: LessonCategory) -> QuizAttempt? {
        quizAttempts
            .filter { $0.category == category }
            .max { lhs, rhs in
                let lhsPct = lhs.total == 0 ? 0 : Double(lhs.score) / Double(lhs.total)
                let rhsPct = rhs.total == 0 ? 0 : Double(rhs.score) / Double(rhs.total)
                return lhsPct < rhsPct
            }
    }

    var averageQuizScorePercent: Double {
        guard !quizAttempts.isEmpty else { return 0 }
        let percentages = quizAttempts.map { attempt -> Double in
            attempt.total == 0 ? 0 : Double(attempt.score) / Double(attempt.total)
        }
        return percentages.reduce(0, +) / Double(percentages.count)
    }

    // MARK: - Reset

    func resetAllProgress() {
        completedLessonIDs.removeAll()
        quizAttempts.removeAll()
        persistLessons()
        persistQuizAttempts()
    }

    // MARK: - Persistence

    private func load() {
        if let idsData = defaults.data(forKey: lessonsKey),
           let ids = try? JSONDecoder().decode(Set<UUID>.self, from: idsData) {
            completedLessonIDs = ids
        }
        if let attemptsData = defaults.data(forKey: quizKey),
           let attempts = try? JSONDecoder().decode([QuizAttempt].self, from: attemptsData) {
            quizAttempts = attempts
        }
    }

    private func persistLessons() {
        if let data = try? JSONEncoder().encode(completedLessonIDs) {
            defaults.set(data, forKey: lessonsKey)
        }
    }

    private func persistQuizAttempts() {
        if let data = try? JSONEncoder().encode(quizAttempts) {
            defaults.set(data, forKey: quizKey)
        }
    }
}
