import SwiftUI

@main
struct FinLitApp: App {
    @StateObject private var progressStore = ProgressStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(progressStore)
        }
    }
}
