import Foundation

enum LessonData {
    static let all: [Lesson] = [
        Lesson(
            title: "Building Your First Budget",
            category: .budgeting,
            summary: "Learn the 50/30/20 rule and how to track where your money actually goes.",
            readingMinutes: 4,
            sections: [
                LessonSection(
                    heading: "Why Budget?",
                    body: "A budget is simply a plan for your money. Without one, it's easy to spend more than you earn without noticing. A good budget tells your money where to go before you spend it, instead of wondering where it went afterward."
                ),
                LessonSection(
                    heading: "The 50/30/20 Rule",
                    body: "One popular framework splits after-tax income into three buckets: 50% for needs (rent, groceries, utilities), 30% for wants (dining out, entertainment, subscriptions), and 20% for savings and debt repayment beyond the minimum. It's a starting point, not a strict law — adjust the percentages to fit your situation."
                ),
                LessonSection(
                    heading: "Tracking Spending",
                    body: "For one month, write down every purchase, even small ones. Group them into categories. Most people are surprised by at least one category — often food delivery or subscriptions. You can't manage what you don't measure."
                ),
                LessonSection(
                    heading: "Zero-Based Budgeting",
                    body: "An alternative approach assigns every dollar of income a job — spending, saving, or debt payoff — until income minus assigned dollars equals zero. This forces intentional decisions rather than letting leftover cash disappear."
                )
            ],
            keyTakeaways: [
                "A budget is a forward-looking plan, not a backward-looking record.",
                "50/30/20 is a flexible starting framework: needs, wants, savings/debt.",
                "Tracking every expense for a month reveals your real spending habits.",
                "Zero-based budgeting gives every dollar a specific purpose."
            ]
        ),
        Lesson(
            title: "Needs vs. Wants",
            category: .budgeting,
            summary: "Sharpen the skill of telling essential spending apart from discretionary spending.",
            readingMinutes: 3,
            sections: [
                LessonSection(
                    heading: "Defining the Line",
                    body: "A need keeps you housed, fed, healthy, and able to work — rent, basic groceries, utilities, transportation to your job. A want improves quality of life but isn't essential — streaming services, dining out, upgraded electronics."
                ),
                LessonSection(
                    heading: "The Gray Area",
                    body: "Some spending is partly need and partly want. A car might be a need for commuting, but a luxury upgrade is the 'want' portion. Recognizing this split helps you find the essential baseline and trim the rest."
                ),
                LessonSection(
                    heading: "A Simple Test",
                    body: "Ask: if I lost my income tomorrow, would I keep paying for this? If the honest answer is no, it's likely a want. This isn't about eliminating every want — it's about spending on wants deliberately, not by default."
                )
            ],
            keyTakeaways: [
                "Needs keep you functioning; wants improve your lifestyle.",
                "Many expenses are a mix of both — separate the essential portion.",
                "The 'income loss' test is a quick way to sort spending."
            ]
        ),
        Lesson(
            title: "Emergency Funds",
            category: .saving,
            summary: "Why a cash cushion matters and how big it should be.",
            readingMinutes: 4,
            sections: [
                LessonSection(
                    heading: "What It's For",
                    body: "An emergency fund is cash set aside for unplanned expenses — a car repair, medical bill, or job loss — so you don't have to rely on high-interest debt when life goes sideways."
                ),
                LessonSection(
                    heading: "How Much to Save",
                    body: "A common guideline is 3 to 6 months of essential living expenses. Someone with unstable income or dependents might aim higher; someone with very stable income and no dependents might be fine closer to 3 months."
                ),
                LessonSection(
                    heading: "Where to Keep It",
                    body: "Emergency funds should be liquid and safe — a high-yield savings account works well. It should be easy to access quickly, but separate enough from checking that it isn't tempting to spend on everyday purchases."
                ),
                LessonSection(
                    heading: "Building It Gradually",
                    body: "Start with a smaller milestone, like $1,000, before tackling the full 3-6 month goal. Automating a fixed transfer each payday — even a small one — builds the habit and the balance over time."
                )
            ],
            keyTakeaways: [
                "Emergency funds prevent unplanned expenses from becoming debt.",
                "A common target is 3-6 months of essential expenses.",
                "Keep it liquid and separate, e.g. a high-yield savings account.",
                "Automate contributions and build up gradually."
            ]
        ),
        Lesson(
            title: "Simple vs. Compound Interest",
            category: .interest,
            summary: "The math behind how money grows — and how debt grows too.",
            readingMinutes: 5,
            sections: [
                LessonSection(
                    heading: "Simple Interest",
                    body: "Simple interest is calculated only on the original principal. If you invest $1,000 at 5% simple interest, you earn $50 every year, no matter how long you hold it, because the calculation never includes previously earned interest."
                ),
                LessonSection(
                    heading: "Compound Interest",
                    body: "Compound interest is calculated on the principal plus any interest already earned. That $1,000 at 5% compounded annually earns $50 in year one, but in year two it earns 5% of $1,050, and so on — the growth accelerates over time."
                ),
                LessonSection(
                    heading: "Why It Matters for Saving",
                    body: "Compound growth is often called one of the most powerful forces in personal finance because time does much of the work. Starting early, even with small amounts, can outperform starting later with larger amounts, simply because compounding has more years to work."
                ),
                LessonSection(
                    heading: "The Flip Side: Debt",
                    body: "Compounding also works against you with debt. Credit card balances that aren't paid off typically compound too, which is why carrying a balance can snowball faster than expected."
                )
            ],
            keyTakeaways: [
                "Simple interest is earned only on the original principal.",
                "Compound interest is earned on principal plus prior interest, accelerating growth.",
                "Starting to save early lets compounding work over more years.",
                "Compounding also accelerates unpaid debt balances."
            ]
        ),
        Lesson(
            title: "Investing Basics: Stocks, Bonds, and Funds",
            category: .investing,
            summary: "An introduction to common building blocks of an investment portfolio.",
            readingMinutes: 6,
            sections: [
                LessonSection(
                    heading: "Stocks",
                    body: "A stock represents partial ownership in a company. Its value rises or falls with the company's performance and market sentiment. Stocks have historically offered higher long-term growth potential than cash savings, but with more short-term volatility."
                ),
                LessonSection(
                    heading: "Bonds",
                    body: "A bond is essentially a loan you make to a government or company, which pays you interest over time and returns your principal at maturity. Bonds are generally less volatile than stocks but usually offer lower long-term returns."
                ),
                LessonSection(
                    heading: "Mutual Funds and ETFs",
                    body: "Rather than picking individual stocks or bonds, funds pool many securities together. An index fund, for example, tracks a market benchmark and offers instant diversification, which reduces the impact of any single investment performing poorly."
                ),
                LessonSection(
                    heading: "Risk and Time Horizon",
                    body: "Generally, the longer your investing time horizon, the more risk (like stocks) you may be able to absorb, since there's more time to recover from downturns. Money needed soon is usually better kept in safer, more liquid assets."
                ),
                LessonSection(
                    heading: "Diversification",
                    body: "Spreading investments across different assets, sectors, and geographies reduces the risk that any single investment's poor performance sinks your entire portfolio — the classic idea of not putting all your eggs in one basket."
                )
            ],
            keyTakeaways: [
                "Stocks are ownership stakes; bonds are loans that pay interest.",
                "Funds pool many securities for instant diversification.",
                "Longer time horizons can generally absorb more investment risk.",
                "Diversification spreads risk across many investments."
            ]
        ),
        Lesson(
            title: "Understanding Credit Scores",
            category: .credit,
            summary: "What goes into a credit score and why it follows you for years.",
            readingMinutes: 5,
            sections: [
                LessonSection(
                    heading: "What a Credit Score Represents",
                    body: "A credit score is a number, commonly ranging from 300 to 850 in the U.S., that estimates how likely you are to repay borrowed money based on your credit history. Lenders, landlords, and sometimes employers use it to assess risk."
                ),
                LessonSection(
                    heading: "What Affects It",
                    body: "Common factors include payment history (paying on time), credit utilization (how much of your available credit you're using), length of credit history, types of credit used, and recent credit inquiries. Payment history and utilization typically carry the most weight."
                ),
                LessonSection(
                    heading: "Credit Utilization",
                    body: "This is the percentage of your available credit that you're currently using. Keeping utilization low — often suggested under 30% — signals you aren't overly reliant on borrowed money."
                ),
                LessonSection(
                    heading: "Why It Matters",
                    body: "A higher score can mean access to lower interest rates on loans and credit cards, easier approval for renting an apartment, and sometimes better insurance rates. A single late payment can affect a score for years, which is why consistency matters more than any single action."
                )
            ],
            keyTakeaways: [
                "Credit scores estimate the likelihood you'll repay borrowed money.",
                "Payment history and credit utilization are typically the biggest factors.",
                "Keeping utilization low helps protect your score.",
                "Scores affect loan rates, approvals, and sometimes even rent or insurance."
            ]
        ),
        Lesson(
            title: "Good Debt vs. Bad Debt",
            category: .debt,
            summary: "Not all debt is equal — understanding the difference helps you borrow wisely.",
            readingMinutes: 4,
            sections: [
                LessonSection(
                    heading: "A Useful Distinction",
                    body: "Debt is often loosely categorized by whether it helps build long-term value at a reasonable cost, versus financing depreciating purchases at a high cost. This isn't a strict rule, but it's a useful lens."
                ),
                LessonSection(
                    heading: "Examples Often Considered 'Good Debt'",
                    body: "A mortgage on a home that can build equity, or a student loan for an education that increases earning potential, are often cited as examples — particularly when the interest rate is relatively low and the investment has a reasonable chance of paying off."
                ),
                LessonSection(
                    heading: "Examples Often Considered 'Bad Debt'",
                    body: "High-interest credit card debt used for depreciating goods, or payday loans with very high fees, are commonly cited as costly debt that can trap borrowers in a cycle of repayment."
                ),
                LessonSection(
                    heading: "The Real Question",
                    body: "Rather than labeling debt as strictly good or bad, it helps to ask: what's the interest rate, what am I financing, and does this debt move me toward or away from my goals?"
                )
            ],
            keyTakeaways: [
                "Debt is sometimes categorized by whether it builds value or finances depreciation.",
                "Mortgages and education loans are often cited examples of lower-cost debt.",
                "High-interest, short-term debt can be costly and hard to escape.",
                "Always weigh interest rate, purpose, and your goals before borrowing."
            ]
        ),
        Lesson(
            title: "Paying Off Debt Strategically",
            category: .debt,
            summary: "Two popular methods for tackling multiple debts: snowball and avalanche.",
            readingMinutes: 4,
            sections: [
                LessonSection(
                    heading: "The Debt Snowball",
                    body: "With this method, you pay minimums on all debts but put extra money toward the smallest balance first. Once it's paid off, you roll that payment into the next-smallest balance. The appeal is psychological — quick wins can build motivation."
                ),
                LessonSection(
                    heading: "The Debt Avalanche",
                    body: "This method instead targets the debt with the highest interest rate first, while paying minimums on the rest. Mathematically, this usually saves the most money in total interest paid over time."
                ),
                LessonSection(
                    heading: "Choosing Between Them",
                    body: "The avalanche method is typically more efficient with money, but the snowball method can be more effective for some people because visible progress keeps them motivated to continue. The best method is often the one you'll actually stick with."
                )
            ],
            keyTakeaways: [
                "Debt snowball: smallest balance first, for motivation.",
                "Debt avalanche: highest interest rate first, to minimize total interest.",
                "Consistency matters more than which method you choose."
            ]
        ),
        Lesson(
            title: "Taxes 101",
            category: .taxes,
            summary: "A plain-language introduction to how income taxes generally work.",
            readingMinutes: 5,
            sections: [
                LessonSection(
                    heading: "Gross vs. Net Income",
                    body: "Gross income is what you earn before deductions. Net (or take-home) income is what's left after taxes and other deductions, like retirement contributions, are subtracted from your paycheck."
                ),
                LessonSection(
                    heading: "Marginal Tax Brackets",
                    body: "Many countries, including the U.S., use progressive tax brackets, meaning different portions of your income are taxed at different rates. Earning more and moving into a higher bracket doesn't mean all your income is taxed at that higher rate — only the portion within that bracket."
                ),
                LessonSection(
                    heading: "Deductions and Credits",
                    body: "A deduction reduces the amount of income that's taxed. A credit directly reduces the tax bill itself, dollar for dollar, which generally makes credits more valuable than deductions of the same amount."
                ),
                LessonSection(
                    heading: "Withholding and Filing",
                    body: "Employers typically withhold estimated taxes from each paycheck. When you file a tax return, you reconcile what was withheld against what you actually owed — resulting in a refund if you overpaid, or a bill if you underpaid."
                )
            ],
            keyTakeaways: [
                "Net income is what remains after taxes and deductions.",
                "Progressive tax systems tax only the income within each bracket at that bracket's rate.",
                "Credits reduce tax owed directly; deductions reduce taxable income.",
                "Withholding is reconciled against actual tax owed when you file."
            ]
        ),
        Lesson(
            title: "Insurance Basics",
            category: .insurance,
            summary: "Understanding how insurance protects against financial shocks.",
            readingMinutes: 4,
            sections: [
                LessonSection(
                    heading: "The Core Idea",
                    body: "Insurance pools risk across many people. Everyone pays a relatively small, predictable premium, and the pool covers the relatively rare, large losses that any individual member might face."
                ),
                LessonSection(
                    heading: "Common Types",
                    body: "Health insurance covers medical costs. Auto insurance covers vehicle damage and liability. Renters or homeowners insurance covers property and liability. Life insurance provides a payout to beneficiaries if the policyholder dies."
                ),
                LessonSection(
                    heading: "Premiums, Deductibles, and Limits",
                    body: "A premium is what you pay for coverage. A deductible is what you pay out of pocket before insurance kicks in. Coverage limits cap how much the insurer will pay. Generally, a higher deductible means a lower premium, and vice versa."
                ),
                LessonSection(
                    heading: "Why It's Part of a Financial Plan",
                    body: "Insurance doesn't build wealth directly, but it protects wealth you've already built from being wiped out by a single catastrophic event, like a serious accident or a house fire."
                )
            ],
            keyTakeaways: [
                "Insurance pools risk so rare large losses don't fall on one person alone.",
                "Common types include health, auto, property, and life insurance.",
                "Higher deductibles typically mean lower premiums.",
                "Insurance protects existing wealth rather than building new wealth."
            ]
        ),
        Lesson(
            title: "Retirement Accounts: 401(k) and IRA",
            category: .retirement,
            summary: "How tax-advantaged retirement accounts work and why starting early helps.",
            readingMinutes: 5,
            sections: [
                LessonSection(
                    heading: "Why Tax-Advantaged Accounts Exist",
                    body: "Governments often encourage retirement saving by offering accounts with tax benefits, so that growth over decades isn't fully eroded by annual taxes."
                ),
                LessonSection(
                    heading: "401(k) Basics",
                    body: "A 401(k) is an employer-sponsored account in the U.S. Contributions are often made pre-tax, reducing taxable income now, while the money grows tax-deferred until withdrawal in retirement. Many employers offer a matching contribution up to a certain percentage."
                ),
                LessonSection(
                    heading: "Employer Match",
                    body: "An employer match is essentially free money added to your account when you contribute, up to a set limit. Not contributing enough to capture the full match is often described as leaving part of your compensation on the table."
                ),
                LessonSection(
                    heading: "IRA Basics",
                    body: "An Individual Retirement Account (IRA) isn't tied to an employer. A traditional IRA offers similar tax-deferred growth to a 401(k), while a Roth IRA is funded with after-tax dollars but allows qualified withdrawals in retirement to be tax-free."
                ),
                LessonSection(
                    heading: "The Power of Starting Early",
                    body: "Because retirement accounts benefit from compound growth over long periods, starting contributions in your 20s, even in small amounts, can result in a larger balance than starting later with larger contributions."
                )
            ],
            keyTakeaways: [
                "Retirement accounts offer tax advantages to encourage long-term saving.",
                "A 401(k) is employer-sponsored; an IRA is opened individually.",
                "Capturing a full employer match is generally treated as a top priority.",
                "Starting early lets compound growth work over more decades."
            ]
        )
    ]

    static func lessons(for category: LessonCategory) -> [Lesson] {
        all.filter { $0.category == category }
    }
}
