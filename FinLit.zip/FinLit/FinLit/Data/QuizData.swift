import Foundation

enum QuizData {
    static let all: [QuizQuestion] = [
        // Budgeting
        QuizQuestion(
            category: .budgeting,
            prompt: "In the 50/30/20 rule, what does the 20% typically represent?",
            choices: ["Wants", "Needs", "Savings & extra debt repayment", "Taxes"],
            correctIndex: 2,
            explanation: "The 20% bucket is generally reserved for savings and paying down debt beyond the minimum payment."
        ),
        QuizQuestion(
            category: .budgeting,
            prompt: "Which of these is generally considered a 'need' rather than a 'want'?",
            choices: ["Streaming subscriptions", "Basic groceries", "Dining out", "New video game console"],
            correctIndex: 1,
            explanation: "Basic groceries are essential for daily living, making them a need rather than a discretionary want."
        ),
        QuizQuestion(
            category: .budgeting,
            prompt: "What is a zero-based budget?",
            choices: [
                "A budget with no savings goal",
                "A budget where every dollar of income is assigned a purpose",
                "A budget for people with no income",
                "A budget that resets to zero every year"
            ],
            correctIndex: 1,
            explanation: "Zero-based budgeting assigns every dollar a job — spending, saving, or debt payoff — until nothing is left unassigned."
        ),

        // Saving
        QuizQuestion(
            category: .saving,
            prompt: "How many months of essential expenses do many experts suggest for an emergency fund?",
            choices: ["1-2 weeks", "3-6 months", "2-3 years", "It should equal your annual salary"],
            correctIndex: 1,
            explanation: "A common guideline is 3 to 6 months of essential living expenses, adjusted for personal circumstances."
        ),
        QuizQuestion(
            category: .saving,
            prompt: "Where is an emergency fund best kept?",
            choices: [
                "Invested entirely in stocks",
                "A liquid, safe account like a high-yield savings account",
                "Under a mattress",
                "Tied up in real estate"
            ],
            correctIndex: 1,
            explanation: "Emergency funds need to be liquid and safe so they're accessible quickly without risking loss of value."
        ),

        // Interest
        QuizQuestion(
            category: .interest,
            prompt: "What makes compound interest different from simple interest?",
            choices: [
                "Compound interest is always a lower rate",
                "Compound interest is calculated only on the original principal",
                "Compound interest is calculated on principal plus previously earned interest",
                "There is no real difference"
            ],
            correctIndex: 2,
            explanation: "Compound interest grows faster because each period's interest is calculated on principal plus all interest already earned."
        ),
        QuizQuestion(
            category: .interest,
            prompt: "Why does starting to save early matter so much for compound growth?",
            choices: [
                "It doesn't matter, only the amount saved matters",
                "Earlier savings have more time periods for growth to compound",
                "Interest rates are higher when you're younger",
                "Banks require you to start young"
            ],
            correctIndex: 1,
            explanation: "Compounding needs time to work — more years means more compounding periods and larger eventual growth."
        ),

        // Investing
        QuizQuestion(
            category: .investing,
            prompt: "What does owning a stock represent?",
            choices: [
                "A loan to a company",
                "Partial ownership in a company",
                "A guaranteed fixed payment",
                "A type of insurance"
            ],
            correctIndex: 1,
            explanation: "A stock is a share of ownership in a company, so its value moves with the company's performance and market sentiment."
        ),
        QuizQuestion(
            category: .investing,
            prompt: "What is diversification?",
            choices: [
                "Putting all your money in one high-performing stock",
                "Spreading investments across different assets to reduce risk",
                "Only investing in bonds",
                "Investing exclusively in your employer's stock"
            ],
            correctIndex: 1,
            explanation: "Diversification spreads risk across many investments so one poor performer doesn't sink the whole portfolio."
        ),
        QuizQuestion(
            category: .investing,
            prompt: "Generally speaking, how does time horizon relate to investment risk?",
            choices: [
                "Longer horizons can often absorb more risk since there's time to recover",
                "Shorter horizons should always include more stocks",
                "Time horizon has no effect on appropriate risk level",
                "Longer horizons require keeping everything in cash"
            ],
            correctIndex: 0,
            explanation: "A longer time horizon generally allows more time to recover from downturns, which can support taking on more risk."
        ),

        // Credit
        QuizQuestion(
            category: .credit,
            prompt: "What is credit utilization?",
            choices: [
                "The number of credit cards you own",
                "The percentage of available credit currently being used",
                "Your annual income",
                "The interest rate on your mortgage"
            ],
            correctIndex: 1,
            explanation: "Credit utilization measures how much of your available credit you're using, and keeping it low is generally favorable for your score."
        ),
        QuizQuestion(
            category: .credit,
            prompt: "Which factor typically has the biggest impact on a credit score?",
            choices: ["Favorite bank branch", "Payment history", "Eye color", "Number of email addresses"],
            correctIndex: 1,
            explanation: "Payment history — whether you pay on time — is typically one of the most heavily weighted factors in a credit score."
        ),

        // Debt
        QuizQuestion(
            category: .debt,
            prompt: "In the debt avalanche method, which debt do you pay off first?",
            choices: ["The smallest balance", "The one with the highest interest rate", "The oldest debt", "A random debt"],
            correctIndex: 1,
            explanation: "The avalanche method targets the highest interest rate first, which generally minimizes total interest paid."
        ),
        QuizQuestion(
            category: .debt,
            prompt: "What is the main appeal of the debt snowball method?",
            choices: [
                "It always saves the most money in interest",
                "It provides quick psychological wins that build motivation",
                "It's required by law",
                "It eliminates interest entirely"
            ],
            correctIndex: 1,
            explanation: "By paying off the smallest balance first, the snowball method creates visible progress that helps some people stay motivated."
        ),

        // Taxes
        QuizQuestion(
            category: .taxes,
            prompt: "In a progressive tax bracket system, what happens when you earn more and enter a higher bracket?",
            choices: [
                "All of your income is taxed at the new higher rate",
                "Only the income within that higher bracket is taxed at the higher rate",
                "Your taxes are automatically halved",
                "Nothing changes at all"
            ],
            correctIndex: 1,
            explanation: "Only the portion of income that falls within a given bracket is taxed at that bracket's rate — not your entire income."
        ),
        QuizQuestion(
            category: .taxes,
            prompt: "What's the key difference between a tax deduction and a tax credit?",
            choices: [
                "They're exactly the same thing",
                "A deduction reduces taxable income; a credit reduces the tax bill directly",
                "A credit reduces taxable income; a deduction reduces the tax bill directly",
                "Deductions only apply to businesses"
            ],
            correctIndex: 1,
            explanation: "A deduction lowers the income that gets taxed, while a credit lowers the final tax bill dollar-for-dollar."
        ),

        // Insurance
        QuizQuestion(
            category: .insurance,
            prompt: "What is a deductible?",
            choices: [
                "The amount you pay out of pocket before insurance coverage kicks in",
                "The monthly cost of an insurance policy",
                "The maximum amount an insurer will ever pay",
                "A tax deduction related to insurance"
            ],
            correctIndex: 0,
            explanation: "A deductible is the out-of-pocket amount you pay before your insurance starts covering costs."
        ),
        QuizQuestion(
            category: .insurance,
            prompt: "What is the core idea behind insurance?",
            choices: [
                "Guaranteeing profit for the policyholder",
                "Pooling risk across many people so rare large losses don't fall on one person",
                "Avoiding taxes",
                "Replacing the need for an emergency fund"
            ],
            correctIndex: 1,
            explanation: "Insurance pools small, predictable premiums from many people to cover the rare, large losses any individual might face."
        ),

        // Retirement
        QuizQuestion(
            category: .retirement,
            prompt: "What is an employer 401(k) match often compared to?",
            choices: ["A loan you must repay", "Free money added to your retirement savings", "A tax penalty", "An optional bonus with no real value"],
            correctIndex: 1,
            explanation: "An employer match adds money to your account simply for contributing, which is often described as leaving free money on the table if unused."
        ),
        QuizQuestion(
            category: .retirement,
            prompt: "What distinguishes a Roth IRA from a traditional IRA?",
            choices: [
                "Roth IRAs are funded with after-tax dollars and allow tax-free qualified withdrawals",
                "Roth IRAs are only available to employers",
                "Traditional IRAs have no tax benefits at all",
                "There's no meaningful difference"
            ],
            correctIndex: 0,
            explanation: "A Roth IRA uses after-tax contributions, but qualified withdrawals in retirement are generally tax-free."
        )
    ]

    static func questions(for category: LessonCategory) -> [QuizQuestion] {
        all.filter { $0.category == category }
    }
}
