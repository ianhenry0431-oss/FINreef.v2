import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            NavigationStack {
                LearnListView()
            }
            .tabItem {
                Label("Learn", systemImage: "book.fill")
            }

            NavigationStack {
                ToolsListView()
            }
            .tabItem {
                Label("Tools", systemImage: "function")
            }

            NavigationStack {
                QuizListView()
            }
            .tabItem {
                Label("Quiz", systemImage: "checkmark.circle.fill")
            }

            NavigationStack {
                ProgressDashboardView()
            }
            .tabItem {
                Label("Progress", systemImage: "chart.bar.fill")
            }

            NavigationStack {
                GlossaryView()
            }
            .tabItem {
                Label("Glossary", systemImage: "character.book.closed.fill")
            }
        }
        .tint(.green)
    }
}

#Preview {
    ContentView()
        .environmentObject(ProgressStore())
}
