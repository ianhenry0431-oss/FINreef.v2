import SwiftUI

enum LessonCategory: String, CaseIterable, Identifiable, Codable, Hashable {
    case budgeting = "Budgeting"
    case saving = "Saving"
    case interest = "Interest"
    case investing = "Investing"
    case credit = "Credit"
    case debt = "Debt & Loans"
    case taxes = "Taxes"
    case insurance = "Insurance"
    case retirement = "Retirement"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .budgeting: return "chart.pie.fill"
        case .saving: return "banknote.fill"
        case .interest: return "percent"
        case .investing: return "chart.line.uptrend.xyaxis"
        case .credit: return "creditcard.fill"
        case .debt: return "exclamationmark.triangle.fill"
        case .taxes: return "doc.text.fill"
        case .insurance: return "shield.fill"
        case .retirement: return "figure.walk"
        }
    }

    var color: Color {
        switch self {
        case .budgeting: return .green
        case .saving: return .mint
        case .interest: return .orange
        case .investing: return .blue
        case .credit: return .purple
        case .debt: return .red
        case .taxes: return .indigo
        case .insurance: return .teal
        case .retirement: return .brown
        }
    }
}

struct LessonSection: Identifiable, Codable, Hashable {
    let id: UUID
    let heading: String
    let body: String

    init(id: UUID = UUID(), heading: String, body: String) {
        self.id = id
        self.heading = heading
        self.body = body
    }
}

struct Lesson: Identifiable, Codable, Hashable {
    let id: UUID
    let title: String
    let category: LessonCategory
    let summary: String
    let readingMinutes: Int
    let sections: [LessonSection]
    let keyTakeaways: [String]

    init(
        id: UUID = UUID(),
        title: String,
        category: LessonCategory,
        summary: String,
        readingMinutes: Int,
        sections: [LessonSection],
        keyTakeaways: [String]
    ) {
        self.id = id
        self.title = title
        self.category = category
        self.summary = summary
        self.readingMinutes = readingMinutes
        self.sections = sections
        self.keyTakeaways = keyTakeaways
    }
}
