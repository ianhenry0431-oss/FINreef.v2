import Foundation

struct QuizQuestion: Identifiable, Codable {
    let id: UUID
    let category: LessonCategory
    let prompt: String
    let choices: [String]
    let correctIndex: Int
    let explanation: String

    init(
        id: UUID = UUID(),
        category: LessonCategory,
        prompt: String,
        choices: [String],
        correctIndex: Int,
        explanation: String
    ) {
        self.id = id
        self.category = category
        self.prompt = prompt
        self.choices = choices
        self.correctIndex = correctIndex
        self.explanation = explanation
    }
}

struct QuizAttempt: Codable {
    let category: LessonCategory
    let score: Int
    let total: Int
    let date: Date
}
