import SwiftUI

struct GlossaryTerm: Identifiable {
    let id = UUID()
    let term: String
    let definition: String
}

enum GlossaryData {
    static let terms: [GlossaryTerm] = [
        GlossaryTerm(term: "Annual Percentage Rate (APR)", definition: "The yearly cost of borrowing money, expressed as a percentage, including interest and often certain fees."),
        GlossaryTerm(term: "Asset", definition: "Anything of value that you own, such as cash, investments, or property."),
        GlossaryTerm(term: "Bond", definition: "A loan made to a government or company that pays interest over time and returns the principal at maturity."),
        GlossaryTerm(term: "Compound Interest", definition: "Interest calculated on both the original principal and previously earned interest."),
        GlossaryTerm(term: "Credit Score", definition: "A number estimating how likely a person is to repay borrowed money, based on their credit history."),
        GlossaryTerm(term: "Credit Utilization", definition: "The percentage of available credit currently being used."),
        GlossaryTerm(term: "Debt-to-Income Ratio", definition: "A comparison of monthly debt payments to monthly income, often used by lenders to assess borrowing risk."),
        GlossaryTerm(term: "Deductible", definition: "The amount an insurance policyholder pays out of pocket before coverage begins."),
        GlossaryTerm(term: "Diversification", definition: "Spreading investments across different assets to reduce the risk of any single one causing major losses."),
        GlossaryTerm(term: "Emergency Fund", definition: "Money set aside to cover unplanned expenses, typically kept in a liquid, easily accessible account."),
        GlossaryTerm(term: "Equity", definition: "The value of ownership in an asset after subtracting any debt owed against it, such as a home's value minus the remaining mortgage."),
        GlossaryTerm(term: "ETF (Exchange-Traded Fund)", definition: "A fund that holds a basket of securities and trades on an exchange like a stock."),
        GlossaryTerm(term: "Gross Income", definition: "Total income earned before taxes and other deductions are subtracted."),
        GlossaryTerm(term: "Index Fund", definition: "A fund designed to track the performance of a specific market benchmark, offering broad diversification."),
        GlossaryTerm(term: "Inflation", definition: "The general rise in prices over time, which reduces the purchasing power of money."),
        GlossaryTerm(term: "Liability", definition: "Something you owe, such as a loan, credit card balance, or mortgage."),
        GlossaryTerm(term: "Liquidity", definition: "How quickly and easily an asset can be converted into cash without losing significant value."),
        GlossaryTerm(term: "Net Income", definition: "Income remaining after taxes and other deductions have been subtracted from gross income."),
        GlossaryTerm(term: "Premium", definition: "The amount paid, usually periodically, for an insurance policy."),
        GlossaryTerm(term: "Principal", definition: "The original amount of money invested or borrowed, not including interest or returns."),
        GlossaryTerm(term: "Roth IRA", definition: "A retirement account funded with after-tax dollars that allows qualified withdrawals to be tax-free."),
        GlossaryTerm(term: "Simple Interest", definition: "Interest calculated only on the original principal, not on previously earned interest."),
        GlossaryTerm(term: "Traditional IRA", definition: "An individual retirement account that typically offers tax-deferred growth, with taxes paid upon withdrawal."),
        GlossaryTerm(term: "401(k)", definition: "An employer-sponsored retirement account, often with pre-tax contributions and sometimes an employer matching contribution.")
    ]
}

struct GlossaryView: View {
    @State private var searchText = ""

    private var filteredTerms: [GlossaryTerm] {
        guard !searchText.isEmpty else { return GlossaryData.terms }
        return GlossaryData.terms.filter {
            $0.term.localizedCaseInsensitiveContains(searchText) ||
            $0.definition.localizedCaseInsensitiveContains(searchText)
        }
    }

    var body: some View {
        List {
            ForEach(filteredTerms) { entry in
                VStack(alignment: .leading, spacing: 4) {
                    Text(entry.term)
                        .font(.body.weight(.semibold))
                    Text(entry.definition)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 4)
            }
        }
        .navigationTitle("Glossary")
        .searchable(text: $searchText, prompt: "Search terms")
    }
}

#Preview {
    NavigationStack {
        GlossaryView()
    }
}
