import SwiftUI

struct QuizListView: View {
    @EnvironmentObject private var progressStore: ProgressStore

    private var categoriesWithQuestions: [LessonCategory] {
        LessonCategory.allCases.filter { !QuizData.questions(for: $0).isEmpty }
    }

    var body: some View {
        List {
            Section {
                Text("Test what you've learned. Each quiz pulls questions from that topic's lessons.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Section("Topics") {
                ForEach(categoriesWithQuestions) { category in
                    NavigationLink {
                        QuizView(category: category)
                    } label: {
                        QuizRow(category: category, bestAttempt: progressStore.bestAttempt(for: category))
                    }
                }
            }
        }
        .navigationTitle("Quiz")
    }
}

private struct QuizRow: View {
    let category: LessonCategory
    let bestAttempt: QuizAttempt?

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: category.icon)
                .foregroundStyle(category.color)
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(category.rawValue)
                    .font(.body.weight(.medium))
                Text("\(QuizData.questions(for: category).count) questions")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if let bestAttempt {
                Text("Best: \(bestAttempt.score)/\(bestAttempt.total)")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.green)
            }
        }
        .padding(.vertical, 2)
    }
}

#Preview {
    NavigationStack {
        QuizListView()
    }
    .environmentObject(ProgressStore())
}
