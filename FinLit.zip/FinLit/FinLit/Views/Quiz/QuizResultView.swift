import SwiftUI

struct QuizResultView: View {
    let category: LessonCategory
    let score: Int
    let total: Int
    let onRetry: () -> Void

    private var percent: Double {
        total == 0 ? 0 : Double(score) / Double(total)
    }

    private var message: String {
        switch percent {
        case 0.9...: return "Outstanding! You've really got this topic down."
        case 0.7..<0.9: return "Great work! A little more review and you'll master this."
        case 0.5..<0.7: return "Good effort. Revisit the lessons to strengthen a few areas."
        default: return "This topic needs more review — head back to the lessons and try again."
        }
    }

    var body: some View {
        VStack(spacing: 24) {
            Spacer()

            Image(systemName: percent >= 0.7 ? "trophy.fill" : "book.fill")
                .font(.system(size: 56))
                .foregroundStyle(category.color)

            Text("\(score) / \(total)")
                .font(.system(size: 48, weight: .bold, design: .rounded))

            Text(message)
                .font(.body)
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 32)

            Spacer()

            VStack(spacing: 12) {
                Button("Try Again") {
                    onRetry()
                }
                .buttonStyle(.borderedProminent)
                .tint(category.color)
                .frame(maxWidth: .infinity)

                NavigationLink("Review \(category.rawValue) Lessons") {
                    LearnListView()
                }
                .frame(maxWidth: .infinity)
            }
            .padding(.horizontal)
        }
        .padding()
    }
}

#Preview {
    NavigationStack {
        QuizResultView(category: .budgeting, score: 4, total: 5, onRetry: {})
    }
    .environmentObject(ProgressStore())
}
