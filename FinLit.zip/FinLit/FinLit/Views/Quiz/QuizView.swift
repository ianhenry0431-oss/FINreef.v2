import SwiftUI

struct QuizView: View {
    let category: LessonCategory

    @EnvironmentObject private var progressStore: ProgressStore
    @State private var questions: [QuizQuestion]
    @State private var currentIndex = 0
    @State private var selectedIndex: Int? = nil
    @State private var score = 0
    @State private var isFinished = false

    init(category: LessonCategory) {
        self.category = category
        _questions = State(initialValue: QuizData.questions(for: category).shuffled())
    }

    var body: some View {
        Group {
            if isFinished {
                QuizResultView(
                    category: category,
                    score: score,
                    total: questions.count,
                    onRetry: restart
                )
            } else if let question = currentQuestion {
                quizContent(for: question)
            } else {
                Text("No questions available for this topic yet.")
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle(category.rawValue)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var currentQuestion: QuizQuestion? {
        guard currentIndex < questions.count else { return nil }
        return questions[currentIndex]
    }

    private func quizContent(for question: QuizQuestion) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack {
                    Text("Question \(currentIndex + 1) of \(questions.count)")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text("Score: \(score)")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.green)
                }

                ProgressView(value: Double(currentIndex), total: Double(questions.count))
                    .tint(category.color)

                Text(question.prompt)
                    .font(.title3.weight(.semibold))

                VStack(spacing: 10) {
                    ForEach(question.choices.indices, id: \.self) { index in
                        choiceButton(index: index, question: question)
                    }
                }

                if selectedIndex != nil {
                    explanationCard(for: question)

                    Button(currentIndex == questions.count - 1 ? "See Results" : "Next Question") {
                        advance()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(category.color)
                    .frame(maxWidth: .infinity)
                }
            }
            .padding()
        }
    }

    private func choiceButton(index: Int, question: QuizQuestion) -> some View {
        let isSelected = selectedIndex == index
        let isCorrect = index == question.correctIndex
        let showFeedback = selectedIndex != nil

        var background: Color = Color(.secondarySystemBackground)
        if showFeedback {
            if isCorrect {
                background = Color.green.opacity(0.2)
            } else if isSelected {
                background = Color.red.opacity(0.2)
            }
        }

        return Button {
            guard selectedIndex == nil else { return }
            selectedIndex = index
            if isCorrect {
                score += 1
            }
        } label: {
            HStack {
                Text(question.choices[index])
                    .multilineTextAlignment(.leading)
                Spacer()
                if showFeedback && isCorrect {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                } else if showFeedback && isSelected {
                    Image(systemName: "xmark.circle.fill").foregroundStyle(.red)
                }
            }
            .padding()
            .background(background)
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .foregroundStyle(.primary)
        .disabled(selectedIndex != nil)
    }

    private func explanationCard(for question: QuizQuestion) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "lightbulb.fill")
                .foregroundStyle(.yellow)
            Text(question.explanation)
                .font(.subheadline)
        }
        .padding()
        .background(Color.yellow.opacity(0.12))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private func advance() {
        if currentIndex == questions.count - 1 {
            progressStore.recordQuizAttempt(category: category, score: score, total: questions.count)
            isFinished = true
        } else {
            currentIndex += 1
            selectedIndex = nil
        }
    }

    private func restart() {
        questions = QuizData.questions(for: category).shuffled()
        currentIndex = 0
        selectedIndex = nil
        score = 0
        isFinished = false
    }
}

#Preview {
    NavigationStack {
        QuizView(category: .budgeting)
    }
    .environmentObject(ProgressStore())
}
