import SwiftUI

struct ProgressDashboardView: View {
    @EnvironmentObject private var progressStore: ProgressStore
    @State private var showingResetConfirmation = false

    var body: some View {
        List {
            Section {
                VStack(spacing: 16) {
                    ZStack {
                        Circle()
                            .stroke(Color(.systemGray5), lineWidth: 12)
                        Circle()
                            .trim(from: 0, to: progressStore.overallLessonProgress)
                            .stroke(Color.green, style: StrokeStyle(lineWidth: 12, lineCap: .round))
                            .rotationEffect(.degrees(-90))
                        VStack {
                            Text("\(Int(progressStore.overallLessonProgress * 100))%")
                                .font(.title.bold())
                            Text("Complete")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .frame(width: 140, height: 140)

                    Text("\(progressStore.completedLessonCount) of \(progressStore.totalLessons) lessons finished")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)

                    if !progressStore.quizAttempts.isEmpty {
                        Text("Average quiz score: \(Int(progressStore.averageQuizScorePercent * 100))%")
                            .font(.subheadline)
                            .foregroundStyle(.blue)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
            }

            Section("By Topic") {
                ForEach(LessonCategory.allCases) { category in
                    let lessons = LessonData.lessons(for: category)
                    if !lessons.isEmpty {
                        CategoryProgressRow(
                            category: category,
                            progress: progressStore.progress(for: category),
                            bestAttempt: progressStore.bestAttempt(for: category)
                        )
                    }
                }
            }

            Section {
                Button(role: .destructive) {
                    showingResetConfirmation = true
                } label: {
                    Label("Reset All Progress", systemImage: "arrow.counterclockwise")
                }
            }
        }
        .navigationTitle("Progress")
        .confirmationDialog(
            "Reset all progress?",
            isPresented: $showingResetConfirmation,
            titleVisibility: .visible
        ) {
            Button("Reset Everything", role: .destructive) {
                progressStore.resetAllProgress()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This will clear all completed lessons and quiz history. This can't be undone.")
        }
    }
}

private struct CategoryProgressRow: View {
    let category: LessonCategory
    let progress: Double
    let bestAttempt: QuizAttempt?

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: category.icon)
                    .foregroundStyle(category.color)
                Text(category.rawValue)
                    .font(.subheadline.weight(.medium))
                Spacer()
                if let bestAttempt {
                    Text("Quiz: \(bestAttempt.score)/\(bestAttempt.total)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            ProgressView(value: progress)
                .tint(category.color)
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    NavigationStack {
        ProgressDashboardView()
    }
    .environmentObject(ProgressStore())
}
