import SwiftUI

struct LearnListView: View {
    @EnvironmentObject private var progressStore: ProgressStore

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Your Learning Journey")
                        .font(.headline)
                    ProgressView(value: progressStore.overallLessonProgress)
                        .tint(.green)
                    Text("\(progressStore.completedLessonCount) of \(progressStore.totalLessons) lessons complete")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 4)
            }

            ForEach(LessonCategory.allCases) { category in
                let lessons = LessonData.lessons(for: category)
                if !lessons.isEmpty {
                    Section {
                        ForEach(lessons) { lesson in
                            NavigationLink(value: lesson) {
                                LessonRow(lesson: lesson, isComplete: progressStore.isLessonComplete(lesson))
                            }
                        }
                    } header: {
                        Label(category.rawValue, systemImage: category.icon)
                    }
                }
            }
        }
        .navigationTitle("Learn")
        .navigationDestination(for: Lesson.self) { lesson in
            LessonDetailView(lesson: lesson)
        }
    }
}

private struct LessonRow: View {
    let lesson: Lesson
    let isComplete: Bool

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(lesson.title)
                    .font(.body.weight(.medium))
                Text(lesson.summary)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                Text("\(lesson.readingMinutes) min read")
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
            }
            Spacer()
            if isComplete {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.green)
            }
        }
        .padding(.vertical, 2)
    }
}

#Preview {
    NavigationStack {
        LearnListView()
    }
    .environmentObject(ProgressStore())
}
