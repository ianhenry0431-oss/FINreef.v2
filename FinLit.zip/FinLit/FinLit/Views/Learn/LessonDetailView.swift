import SwiftUI

struct LessonDetailView: View {
    let lesson: Lesson
    @EnvironmentObject private var progressStore: ProgressStore

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                header

                ForEach(lesson.sections) { section in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(section.heading)
                            .font(.title3.weight(.semibold))
                        Text(section.body)
                            .font(.body)
                            .foregroundStyle(.primary.opacity(0.85))
                    }
                }

                takeawaysCard

                completeButton
            }
            .padding()
        }
        .navigationTitle(lesson.category.rawValue)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: lesson.category.icon)
                    .foregroundStyle(lesson.category.color)
                Text(lesson.category.rawValue.uppercased())
                    .font(.caption.weight(.bold))
                    .foregroundStyle(lesson.category.color)
                Spacer()
                Text("\(lesson.readingMinutes) min")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Text(lesson.title)
                .font(.largeTitle.weight(.bold))
            Text(lesson.summary)
                .font(.body)
                .foregroundStyle(.secondary)
        }
    }

    private var takeawaysCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Key Takeaways", systemImage: "star.fill")
                .font(.headline)
                .foregroundStyle(.orange)
            ForEach(lesson.keyTakeaways, id: \.self) { takeaway in
                HStack(alignment: .top, spacing: 8) {
                    Text("•")
                    Text(takeaway)
                        .font(.subheadline)
                }
            }
        }
        .padding()
        .background(Color.orange.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var completeButton: some View {
        let isComplete = progressStore.isLessonComplete(lesson)
        return Button {
            progressStore.markLessonComplete(lesson)
        } label: {
            Label(
                isComplete ? "Lesson Completed" : "Mark as Complete",
                systemImage: isComplete ? "checkmark.circle.fill" : "circle"
            )
            .frame(maxWidth: .infinity)
            .padding()
            .background(isComplete ? Color.green.opacity(0.15) : Color.green)
            .foregroundStyle(isComplete ? Color.green : Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 14))
        }
        .disabled(isComplete)
    }
}

#Preview {
    NavigationStack {
        LessonDetailView(lesson: LessonData.all[0])
    }
    .environmentObject(ProgressStore())
}
