import SwiftUI
import Charts

struct BudgetCalculatorView: View {
    @State private var monthlyIncome: Double = 4000
    @State private var needsPercent: Double = 50
    @State private var wantsPercent: Double = 30
    @State private var savingsPercent: Double = 20

    private var needsAmount: Double { monthlyIncome * needsPercent / 100 }
    private var wantsAmount: Double { monthlyIncome * wantsPercent / 100 }
    private var savingsAmount: Double { monthlyIncome * savingsPercent / 100 }
    private var totalPercent: Double { needsPercent + wantsPercent + savingsPercent }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                incomeCard
                breakdownChart
                sliders
                if abs(totalPercent - 100) > 0.5 {
                    warningBanner
                }
            }
            .padding()
        }
        .navigationTitle("Budget Calculator")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var incomeCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Monthly After-Tax Income")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text(currencyString(monthlyIncome))
                .font(.system(size: 32, weight: .bold, design: .rounded))
            Slider(value: $monthlyIncome, in: 0...15_000, step: 100)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private var breakdownChart: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Your Breakdown")
                .font(.headline)

            Chart {
                SectorMark(angle: .value("Needs", max(needsAmount, 0)), innerRadius: .ratio(0.6))
                    .foregroundStyle(Color.green)
                SectorMark(angle: .value("Wants", max(wantsAmount, 0)), innerRadius: .ratio(0.6))
                    .foregroundStyle(Color.orange)
                SectorMark(angle: .value("Savings", max(savingsAmount, 0)), innerRadius: .ratio(0.6))
                    .foregroundStyle(Color.blue)
            }
            .frame(height: 180)

            VStack(spacing: 10) {
                budgetRow(label: "Needs", amount: needsAmount, percent: needsPercent, color: .green)
                budgetRow(label: "Wants", amount: wantsAmount, percent: wantsPercent, color: .orange)
                budgetRow(label: "Savings & Debt Payoff", amount: savingsAmount, percent: savingsPercent, color: .blue)
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private func budgetRow(label: String, amount: Double, percent: Double, color: Color) -> some View {
        HStack {
            Circle().fill(color).frame(width: 10, height: 10)
            Text(label)
                .font(.subheadline)
            Spacer()
            Text("\(Int(percent))%")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text(currencyString(amount))
                .font(.subheadline.weight(.semibold))
                .frame(width: 90, alignment: .trailing)
        }
    }

    private var sliders: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Adjust the Split")
                .font(.headline)

            percentSlider(label: "Needs", value: $needsPercent, color: .green)
            percentSlider(label: "Wants", value: $wantsPercent, color: .orange)
            percentSlider(label: "Savings & Debt Payoff", value: $savingsPercent, color: .blue)

            Button("Reset to 50 / 30 / 20") {
                needsPercent = 50
                wantsPercent = 30
                savingsPercent = 20
            }
            .font(.subheadline)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private func percentSlider(label: String, value: Binding<Double>, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Circle().fill(color).frame(width: 8, height: 8)
                Text(label)
                Spacer()
                Text("\(Int(value.wrappedValue))%").foregroundStyle(.secondary)
            }
            Slider(value: value, in: 0...100, step: 1)
                .tint(color)
        }
    }

    private var warningBanner: some View {
        HStack(spacing: 8) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.orange)
            Text("Your percentages add up to \(Int(totalPercent))%, not 100%. Adjust the sliders so they total 100%.")
                .font(.caption)
        }
        .padding()
        .background(Color.orange.opacity(0.12))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private func currencyString(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = "USD"
        formatter.maximumFractionDigits = 0
        return formatter.string(from: NSNumber(value: value)) ?? "$0"
    }
}

#Preview {
    NavigationStack {
        BudgetCalculatorView()
    }
}
