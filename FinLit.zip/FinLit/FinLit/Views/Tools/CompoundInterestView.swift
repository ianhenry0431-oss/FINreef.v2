import SwiftUI
import Charts

struct CompoundInterestView: View {
    @State private var principal: Double = 1000
    @State private var monthlyContribution: Double = 100
    @State private var annualRatePercent: Double = 7
    @State private var years: Double = 20
    private let compoundsPerYear: Double = 12

    private var yearlyBalances: [YearBalance] {
        var results: [YearBalance] = []
        let rate = annualRatePercent / 100
        let n = compoundsPerYear
        var balance = principal
        var totalContributed = principal

        results.append(YearBalance(year: 0, balance: balance, contributed: totalContributed))

        for year in 1...max(Int(years), 1) {
            for _ in 0..<Int(n) {
                balance *= (1 + rate / n)
                balance += monthlyContribution * (12 / n)
                totalContributed += monthlyContribution * (12 / n)
            }
            results.append(YearBalance(year: year, balance: balance, contributed: totalContributed))
        }
        return results
    }

    private var finalBalance: Double { yearlyBalances.last?.balance ?? principal }
    private var totalContributed: Double { yearlyBalances.last?.contributed ?? principal }
    private var totalGrowth: Double { finalBalance - totalContributed }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                resultsCard
                chartCard
                inputsCard
            }
            .padding()
        }
        .navigationTitle("Compound Interest")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var resultsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Projected Balance After \(Int(years)) Years")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text(currencyString(finalBalance))
                .font(.system(size: 36, weight: .bold, design: .rounded))
                .foregroundStyle(.green)

            HStack {
                statBlock(label: "You Contributed", value: totalContributed, color: .blue)
                Spacer()
                statBlock(label: "Growth from Interest", value: totalGrowth, color: .orange)
            }
        }
        .padding()
        .background(Color.green.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private func statBlock(label: String, value: Double, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(currencyString(value))
                .font(.headline)
                .foregroundStyle(color)
        }
    }

    private var chartCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Growth Over Time")
                .font(.headline)
            Chart(yearlyBalances) { point in
                AreaMark(
                    x: .value("Year", point.year),
                    y: .value("Balance", point.balance)
                )
                .foregroundStyle(Color.green.opacity(0.25))

                LineMark(
                    x: .value("Year", point.year),
                    y: .value("Balance", point.balance)
                )
                .foregroundStyle(Color.green)

                LineMark(
                    x: .value("Year", point.year),
                    y: .value("Contributed", point.contributed)
                )
                .foregroundStyle(Color.blue)
                .lineStyle(StrokeStyle(lineWidth: 1.5, dash: [4, 4]))
            }
            .frame(height: 200)

            HStack(spacing: 16) {
                legendDot(color: .green, label: "Total Balance")
                legendDot(color: .blue, label: "Amount Contributed")
            }
            .font(.caption)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private func legendDot(color: Color, label: String) -> some View {
        HStack(spacing: 4) {
            Circle().fill(color).frame(width: 8, height: 8)
            Text(label).foregroundStyle(.secondary)
        }
    }

    private var inputsCard: some View {
        VStack(alignment: .leading, spacing: 20) {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text("Starting Amount")
                    Spacer()
                    Text(currencyString(principal)).foregroundStyle(.secondary)
                }
                Slider(value: $principal, in: 0...50_000, step: 100)
            }

            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text("Monthly Contribution")
                    Spacer()
                    Text(currencyString(monthlyContribution)).foregroundStyle(.secondary)
                }
                Slider(value: $monthlyContribution, in: 0...3_000, step: 25)
            }

            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text("Annual Interest Rate")
                    Spacer()
                    Text(String(format: "%.1f%%", annualRatePercent)).foregroundStyle(.secondary)
                }
                Slider(value: $annualRatePercent, in: 0...15, step: 0.5)
            }

            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text("Years Invested")
                    Spacer()
                    Text("\(Int(years)) yrs").foregroundStyle(.secondary)
                }
                Slider(value: $years, in: 1...40, step: 1)
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private func currencyString(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = "USD"
        formatter.maximumFractionDigits = 0
        return formatter.string(from: NSNumber(value: value)) ?? "$0"
    }
}

private struct YearBalance: Identifiable {
    var id: Int { year }
    let year: Int
    let balance: Double
    let contributed: Double
}

#Preview {
    NavigationStack {
        CompoundInterestView()
    }
}
