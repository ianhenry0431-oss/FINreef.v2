import SwiftUI

struct ToolsListView: View {
    var body: some View {
        List {
            Section {
                NavigationLink {
                    CompoundInterestView()
                } label: {
                    ToolRow(
                        icon: "chart.line.uptrend.xyaxis",
                        color: .orange,
                        title: "Compound Interest Calculator",
                        subtitle: "See how savings grow over time"
                    )
                }

                NavigationLink {
                    BudgetCalculatorView()
                } label: {
                    ToolRow(
                        icon: "chart.pie.fill",
                        color: .green,
                        title: "50/30/20 Budget Calculator",
                        subtitle: "Split your income into needs, wants, and savings"
                    )
                }
            } header: {
                Text("Interactive Tools")
            } footer: {
                Text("These calculators are for educational purposes only and don't constitute financial advice.")
            }
        }
        .navigationTitle("Tools")
    }
}

private struct ToolRow: View {
    let icon: String
    let color: Color
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(color)
                .frame(width: 32)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.body.weight(.medium))
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    NavigationStack {
        ToolsListView()
    }
}
