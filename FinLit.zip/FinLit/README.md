# FinLit — Financial Literacy iOS App (SwiftUI)

A native iOS app covering budgeting, saving, interest, investing, credit, debt,
taxes, insurance, and retirement — with lessons, two interactive calculators,
topic quizzes, a progress dashboard, and a glossary. Progress is saved locally
on-device with `UserDefaults` (no backend required).

## What's included

```
FinLit/
├── FinLitApp.swift                        # App entry point
├── ContentView.swift                      # Root TabView (5 tabs)
├── Models/
│   ├── Lesson.swift                       # Lesson + category models
│   └── QuizQuestion.swift                 # Quiz question + attempt models
├── Data/
│   ├── LessonData.swift                   # 12 lessons across 9 topics
│   └── QuizData.swift                     # 20 quiz questions
├── Stores/
│   └── ProgressStore.swift                # Persists completion + quiz scores
└── Views/
    ├── Learn/
    │   ├── LearnListView.swift
    │   └── LessonDetailView.swift
    ├── Tools/
    │   ├── ToolsListView.swift
    │   ├── CompoundInterestView.swift      # Interactive chart + sliders
    │   └── BudgetCalculatorView.swift      # 50/30/20 donut chart + sliders
    ├── Quiz/
    │   ├── QuizListView.swift
    │   ├── QuizView.swift
    │   └── QuizResultView.swift
    ├── Progress/
    │   └── ProgressDashboardView.swift
    └── Glossary/
        └── GlossaryView.swift
```

## Requirements

- Xcode 15 or later
- iOS 17.0+ deployment target (uses Swift Charts' `SectorMark` for the donut
  chart — drop the budget donut chart or swap it for a `BarMark` if you need
  to support iOS 16)

## Setup (5 minutes)

1. Open Xcode → **File → New → Project → iOS → App**.
2. Product Name: `FinLit`, Interface: **SwiftUI**, Language: **Swift**.
3. Once created, delete Xcode's default `ContentView.swift` (keep
   `FinLitApp.swift` or delete it too — we're replacing both).
4. Drag the `FinLit` folder from this download into your Xcode project
   navigator (check **"Copy items if needed"** and **"Create groups"**).
5. Select your target → **General** tab → set **Minimum Deployments** to
   iOS 17.0.
6. Build and run (⌘R) on a simulator or device.

No third-party dependencies, no API keys, no network access required —
everything runs fully offline.

## Extending it

- **Add lessons/quiz questions**: append to `LessonData.all` / `QuizData.all`.
  Each lesson auto-appears under its `LessonCategory` in the Learn tab and
  progress dashboard.
- **Add a new topic**: add a case to `LessonCategory` (pick an SF Symbol +
  color), then add lessons/questions tagged with it.
- **Persistence**: `ProgressStore` currently uses `UserDefaults`. Swap in
  `SwiftData` or CloudKit if you want sync across devices later.
- **Content disclaimer**: this app is educational, not financial advice —
  the Tools section footer already says so; keep that framing if you extend
  it with real calculators.
